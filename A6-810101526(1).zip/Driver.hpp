#pragma once
#include "mission_exception.hpp"
#include "mission.hpp"
#include <vector>

class Driver
{
public:
    Driver(std::string id_, Mission*  mission_)
    {
        driver_id = id_;
        add_misssion_assignment(mission_);
    }

    int get_number_of_missions() { return all_mission.size(); }
    std::string get_id() { return driver_id; }
    void add_misssion_assignment(Mission* mission)
    {
        Mission*  mission_ = mission->create_copy();

        for (int i = 0; i < all_mission.size(); i++)
        {
            if (mission_->get_mission_id() == all_mission[i]->get_mission_id())
                throw DuplicateDriverMission(DUPLICATE_DRIVER_MISSION);
        }
        all_mission.push_back(mission_);
    }
    std::vector<Mission* > get_all_missions() { return all_mission; }

private:
    std::vector<Mission* > all_mission;
    std::string driver_id;
};