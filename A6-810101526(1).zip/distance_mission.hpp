#pragma once
#include <iostream>
#include "mission.hpp"
#include "mission_exception.hpp"
class distance_mission : public Mission
{

private:
    int distance;

public:
    virtual Mission *create_copy()
    {
        std::stringstream mi_info;
        std::string start_time_str, end_time_str, reward_str, distance_str;
        mi_info << start_time_stamp << " " << end_time_stamp << " " << distance << " " << reward;
        mi_info >> start_time_str >> end_time_str >> distance_str >> reward_str;
        return new distance_mission(mission_id, start_time_str, end_time_str, distance_str, reward_str);
    }
    void set_distance(int distance_) { distance = distance_; }
    int get_distance() { return distance; }
    distance_mission(std::string mission_id_str_form, std::string start_time_stamp_str_form, std::string end_time_stamp_str_form, std::string distance_, std::string reward_)
        : Mission(mission_id_str_form, start_time_stamp_str_form, end_time_stamp_str_form, reward_)
    {
        distance = stoi(distance_);
        if (distance_ == "" || distance < 0)
            throw InvalidArgument(INVALID_ARGUMENTS);
    }
    ~distance_mission();

    void calculate_mission(long long int start_time_stamp_, long long int end_time_stamp_, int distance_)
    {
        distance = distance - distance_;
        if (distance <= 0)
            status = COMPLETED_MISSION;
        
    }
};