#pragma once
#include "mission.hpp"
#include "const_statements.hpp"
#include "Driver.hpp"

#include <vector>

class DataBase
{
public:
    void assign_mission(std::string mission_id_, std::string driver_id);
    std::vector<std::string> read_input(int number_of_arguments);
    std::vector<Driver *> get_drivers_data() { return Drivers_data; }

    template <typename T>
    void add_mission(std::vector<std::string> arguments)
    {

        check_duplicate_id(arguments[1]);
        if (stoll(arguments[2]) > stoll(arguments[3]))
            throw InvalidArgument(INVALID_ARGUMENTS);
        total_mission.push_back(new T(arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]));
    }

    std::vector<Mission *> total_mission;
    void show_mission_status(std::string driver_id_);
    void record_drive(std::vector<std::string> arguments);
    void print_mission(std::vector<Mission *> mission_);
    void print_success_massage(const std::string massage) {std:: cout << massage << '\n'; }

private:
    bool find_driver(std::string id_);
    Mission* check_mission(std::string mission_id_);
    void check_duplicate_id(std::string mission_id);
    bool comparator(Mission *lhs, Mission *&rhs);
    void sort(std::vector<Mission *> &mission_);
    void add_driver_mission(std::string id, Mission *mission_);
    Driver *check_driver(std::string is);

    std::vector<Driver *> Drivers_data;
};