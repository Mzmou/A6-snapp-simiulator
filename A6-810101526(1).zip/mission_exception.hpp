#pragma once
#include <iostream>
class Exception
{
public:
    Exception( std::string s) { set_err_sentence(s); }
    void print_error() { std::cout << err_sentence << '\n'; }

protected:
    std::string err_sentence;
    void set_err_sentence(std ::string s) { err_sentence = s; }
};
class InvalidArgument : public Exception
{
public:
    InvalidArgument(std::string s) : Exception(s) { set_err_sentence(s); }
};
class MissionNotFound : public Exception
{
public:
    MissionNotFound(std::string s) : Exception(s) { set_err_sentence(s); }
};
class DriverMissionNotFound : public Exception
{
public:
    DriverMissionNotFound(std::string s) : Exception(s) { set_err_sentence(s); }
};
class DuplicateMissionId : public Exception
{
public:
    DuplicateMissionId(std::string s) : Exception(s) { set_err_sentence(s); }
};
class DuplicateDriverMission : public Exception
{
public:
    DuplicateDriverMission(std::string s) : Exception(s) { set_err_sentence(s); }
};