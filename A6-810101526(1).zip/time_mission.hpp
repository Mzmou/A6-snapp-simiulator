#pragma once
#include <iostream>
#include "mission.hpp"
class time_mission : public Mission
{
private:
    int time;
    virtual void calculate_mission(long long int start_time_stamp_, long long int end_time_stamp_, int distance_)
    {
        time = time - (end_time_stamp_ - start_time_stamp_);
        if (time <= 0)
            status = COMPLETED_MISSION;
        
    }
    virtual Mission *create_copy()
    {
        std::stringstream mi_info;
        std::string start_time_str, end_time_str, reward_str, time_str;
        mi_info << start_time_stamp << " " << end_time_stamp << " " << time << " " << reward;
        mi_info >> start_time_str >> end_time_str >> time_str >> reward_str;
        return new time_mission(mission_id, start_time_str, end_time_str, time_str, reward_str);
    }

public:
    void set_time(int time_) { time = time_*seconds; }
    int get_time() { return time; }
    time_mission(std::string mission_id_str_form, std::string start_time_stamp_str_form, std::string end_time_stamp_str_form, std::string time_, std::string reward_)
        : Mission(mission_id_str_form, start_time_stamp_str_form, end_time_stamp_str_form, reward_)
    {
        if (time_ == "" || std::stoi(time_) < 0)
            throw InvalidArgument(INVALID_ARGUMENTS);
        set_time(std::stoi(time_));
    }
    time_mission()
    {
        set_time(0);
    }
    ~time_mission();
};