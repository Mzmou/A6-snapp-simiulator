#include <iostream>
#include "mission.hpp"
#include "mission_exception.hpp"
#include "const_statements.hpp"
using namespace std;

void Mission::print_mission()
{

    cout << "mission: " << mission_id << '\n';
    cout << "start timestamp: " << start_time_stamp << '\n';
    cout << "end timestamp: " << new_end_time_stamp << '\n';
    cout << "reward: " << reward << '\n';
}
bool Mission ::check_in_interval(long long int start_time_stamp_, long long int end_time_stamp_)
{
    if (start_time_stamp_ >= start_time_stamp && end_time_stamp_ <= end_time_stamp)
        return true;
    return false;
}