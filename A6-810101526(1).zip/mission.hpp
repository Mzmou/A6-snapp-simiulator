#pragma once
#include <iostream>
#include "const_statements.hpp"
#include "mission_exception.hpp"



class Mission
{
public:
    std::string get_mission_id() { return mission_id; }
    int get_start_time_stamp() { return start_time_stamp; }
    int get_end_time_stamp() { return end_time_stamp; }
    std::string get_status() { return status; }
    int get_reward() { return reward; }
    int get_id() { return id; }
    void set_reward(int r) { reward = r; }
    Mission(std::string mission_id_str_form, std::string start_time_stamp_str_form, std::string end_time_stamp_str_form, std::string reward_)
    {
        mission_id = mission_id_str_form;
        start_time_stamp = stoll(start_time_stamp_str_form);
        end_time_stamp = stoll(end_time_stamp_str_form);
        status = UNCOMPLETED_MISSION;
        set_reward(stoi(reward_));
        new_end_time_stamp = -1;
        if (end_time_stamp < start_time_stamp || reward < 0)
            throw InvalidArgument(INVALID_ARGUMENTS);
    }
    Mission() { set_reward(0); }
    void print_mission();
    virtual void calculate_mission(long long int start_time_stamp_, long long int end_time_stamp_, int distance_) = 0;
    bool check_in_interval(long long int start_time_stamp_, long long int end_time_stamp_);
    long long new_end_time_stamp;
    virtual Mission *create_copy() = 0;

protected:
    std::string mission_id;
    void set_status(std::string status_) { status = status_; }
    long long int start_time_stamp;
    long long int end_time_stamp;
    int reward;
    int id;
    std::string status;
};
