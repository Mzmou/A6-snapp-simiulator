#include "DataBase.hpp"
#include "mission.hpp"
#include <algorithm>
#include <sstream>
using namespace std;
void DataBase::show_mission_status(string driver_id_)
{

    Driver *target_driver = check_driver(driver_id_);
    vector<Mission *> target_mission = target_driver->get_all_missions();
    driver_id_.pop_back();
    cout << "missions status for driver " << driver_id_ << ":" << '\n';
    sort(target_mission);
    for (int i = 0; i < target_mission.size(); i++)
    {
        target_mission[i]->print_mission();
        cout << "status: " << target_mission[i]->get_status() << '\n';
        if (i != target_mission.size() - 1)
            cout << '\n';
    }
}
void DataBase::sort(vector<Mission *> &mission_)
{
    std::sort(mission_.begin(), mission_.end(), [](Mission *lhs, Mission *rhs)
              { return lhs->get_start_time_stamp() < rhs->get_start_time_stamp(); });
}
void DataBase::add_driver_mission(string id, Mission *mission_)
{

    for (int i = 0; i < Drivers_data.size(); i++)
    {
        if (Drivers_data[i]->get_id() == id)
        {

            Drivers_data[i]->add_misssion_assignment(mission_);
            return;
        }
    }

    Drivers_data.push_back(new Driver(id, mission_));
}
void DataBase::assign_mission(string mission_id_, string driver_id_)
{

    Mission *mission_target = check_mission(mission_id_);
    add_driver_mission(driver_id_, mission_target);
}

void DataBase ::check_duplicate_id(string mission_id_)
{

    for (int i = 0; i < total_mission.size(); i++)
    {
        if (total_mission[i]->get_mission_id() == mission_id_)
        {
            throw DuplicateMissionId(DUPLICATE_MISSION_ID);
        }
    }
}
vector<string> DataBase::read_input(int number_of_arguments)
{
    string arguments_str_form;
    getline(cin, arguments_str_form);
    std::stringstream arguments_str_form_ss(arguments_str_form);
    vector<string> arguments;
    string token;

    while (getline(arguments_str_form_ss, token, ' '))
    {
        arguments.push_back(token);
    }

    if (arguments.size() < number_of_arguments)
        throw InvalidArgument(INVALID_ARGUMENTS);
    return arguments;
}
bool DataBase::find_driver(string id_)
{

    for (int i = 0; i < Drivers_data.size(); i++)
    {

        if (stoi(Drivers_data[i]->get_id()) == stoi(id_))
        {

            return true;
        }
    }

    return false;
}
bool DataBase::comparator(Mission *lhs, Mission *&rhs)
{
    return lhs->get_start_time_stamp() < rhs->get_start_time_stamp();
}
Mission *DataBase::check_mission(string mission_id_)
{
    for (int i = 0; i < total_mission.size(); i++)
    {
        if (total_mission[i]->get_mission_id() == mission_id_)
            return total_mission[i];
    }
    throw MissionNotFound(MISSION_NOT_FOUND);
}

Driver *DataBase ::check_driver(string id)
{
    for (int i = 0; i < Drivers_data.size(); i++)
    {
        if (stoi(Drivers_data[i]->get_id()) == stoi(id))
            return Drivers_data[i];
    }
    throw MissionNotFound(MISSION_NOT_FOUND);
}

void DataBase::print_mission(vector<Mission *> mission_)
{
    for (int i = 0; i < mission_.size(); i++)
    {
        mission_[i]->print_mission();
        if (i != mission_.size() - 1)
            cout << '\n';
    }
}
void DataBase::record_drive(vector<string> arguments)
{
    if (!find_driver(arguments[3]))
        return;
    if (stoll(arguments[1]) > stoll(arguments[2]))
        throw InvalidArgument(INVALID_ARGUMENTS);
    Driver *target_driver = check_driver(arguments[3]);
    vector<Mission *> target_missions = target_driver->get_all_missions();
    sort(target_missions);
    vector<Mission *> completed_missisons;
    cout << "completed missions for driver " << arguments[3] << ":\n";
    for (int i = 0; i < target_missions.size(); i++)
    {
        if (target_missions[i]->check_in_interval(stoll(arguments[1]), stoll(arguments[2])) && target_missions[i]->get_status() == UNCOMPLETED_MISSION)
        {
            target_missions[i]->calculate_mission(stoll(arguments[1]), stoll(arguments[2]), stoi(arguments[4]));

            if (target_missions[i]->get_status() == COMPLETED_MISSION)
            {
                target_missions[i]->new_end_time_stamp = stol(arguments[2]);
                completed_missisons.push_back(target_missions[i]);
            }
        }
    }
    print_mission(completed_missisons);
}
