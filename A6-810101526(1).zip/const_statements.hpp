#pragma once
#include  <iostream>
const std::string INVALID_ARGUMENTS = "INVALID_ARGUMENTS";
const std::string MISSION_NOT_FOUND = "MISSION_NOT_FOUND";
const std::string delim = " ";
const std::string DRIVER_MISSION_NOT_FOUND = "DRIVER_MISSION_NOT_FOUND";
const std::string DUPLICATE_MISSION_ID = "DUPLICATE_MISSION_ID";
const std::string DUPLICATE_DRIVER_MISSION = "DUPLICATE_DRIVER_MISSION";
const std::string COMPLETED_MISSION = "completed";
const std::string UNCOMPLETED_MISSION = "ongoing";
const std::string ADD_TIME_MISSION = "add_time_mission";
const std::string ADD_COUNT_MISSION = "add_count_mission";
const std::string ADD_DISTANCE_MISSION = "add_distance_mission";
const std::string SUCESSS_MASSAGE = "OK";
const int seconds = 60;