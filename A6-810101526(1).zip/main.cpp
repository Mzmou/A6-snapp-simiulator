#include <iostream>
#include <vector>
#include <sstream>
#include <map>
#include <bits/stdc++.h>
#include "mission_exception.hpp"
#include "const_statements.hpp"
#include "mission.hpp"
#include "count_misssion.hpp"
#include "time_mission.hpp"
#include "distance_mission.hpp"
#include "Driver.hpp"
#include "DataBase.hpp"
using namespace std;

int main()
{
    string command;
    DataBase new_database;
    while (cin >> command)
    {
        try
        {
            if (command == ADD_COUNT_MISSION)
            {
                vector<string> arguments = new_database.read_input(6);
                new_database.add_mission<count_mission>(arguments);
                new_database.print_success_massage(SUCESSS_MASSAGE);
            }
            else if (command == ADD_DISTANCE_MISSION)
            {
                vector<string> arguments = new_database.read_input(6);
                new_database.add_mission<distance_mission>(arguments);
                new_database.print_success_massage(SUCESSS_MASSAGE);
            }
            else if (command == ADD_TIME_MISSION)
            {
                vector<string> arguments = new_database.read_input(6);
                new_database.add_mission<time_mission>(arguments);
                new_database.print_success_massage(SUCESSS_MASSAGE);
            }
            else if (command == "assign_mission")
            {
                vector<string> arguments = new_database.read_input(3);
                new_database.assign_mission(arguments[1], arguments[2]);
                new_database.print_success_massage(SUCESSS_MASSAGE);
            }
            else if (command == "record_ride")
            {
                vector<string> arguments = new_database.read_input(5);
                new_database.record_drive(arguments);
            }
            else if (command == "show_missions_status")
            {
                vector<string> arguments = new_database.read_input(2);
                new_database.show_mission_status(arguments[1]);
            }
        }

        catch (InvalidArgument &arguments_error)
        {
            arguments_error.print_error();
        }
        catch (DuplicateMissionId &mission_error)
        {
            mission_error.print_error();
        }

        catch (MissionNotFound &mission_error)
        {
            mission_error.print_error();
        }
        catch (DuplicateDriverMission &driver_error)
        {
            driver_error.print_error();
        }
        catch (DriverMissionNotFound &driver_error)
        {
            driver_error.print_error();
        }
    }
}
